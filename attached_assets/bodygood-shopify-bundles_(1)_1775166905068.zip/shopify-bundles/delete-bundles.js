/**
 * Delete all bundle products (for cleanup/redo)
 * Only deletes products with product_type "Bundle"
 * 
 * Usage: node delete-bundles.js
 */

require("dotenv").config();

const SHOP_DOMAIN = process.env.SHOPIFY_SHOP_DOMAIN;
const ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;
const API_VERSION = "2024-10";
const BASE_URL = `https://${SHOP_DOMAIN}/admin/api/${API_VERSION}`;

async function shopifyRequest(endpoint, method = "GET") {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Access-Token": ACCESS_TOKEN,
    },
  });
  if (!response.ok && response.status !== 200) {
    const text = await response.text();
    throw new Error(`API error ${response.status}: ${text}`);
  }
  if (method === "DELETE") return {};
  return response.json();
}

async function main() {
  console.log("Finding bundle products to delete...\n");

  const { products } = await shopifyRequest(
    "/products.json?product_type=Bundle&limit=50"
  );

  if (products.length === 0) {
    console.log("No bundle products found.");
    return;
  }

  console.log(`Found ${products.length} bundle(s). Deleting...\n`);

  for (const p of products) {
    try {
      await shopifyRequest(`/products/${p.id}.json`, "DELETE");
      console.log(`  [DELETED] ${p.title} (${p.id})`);
    } catch (err) {
      console.error(`  [ERROR]   ${p.title}: ${err.message}`);
    }
    await new Promise((r) => setTimeout(r, 500));
  }

  console.log("\nDone.");
}

main().catch(console.error);
