/**
 * Verify bundle products exist in Shopify and display their details
 * Run after create-bundles.js to confirm everything looks right
 * 
 * Usage: node verify-bundles.js
 */

require("dotenv").config();

const SHOP_DOMAIN = process.env.SHOPIFY_SHOP_DOMAIN;
const ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;
const API_VERSION = "2024-10";
const BASE_URL = `https://${SHOP_DOMAIN}/admin/api/${API_VERSION}`;

async function shopifyRequest(endpoint) {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Access-Token": ACCESS_TOKEN,
    },
  });
  if (!response.ok) throw new Error(`API error: ${response.status}`);
  return response.json();
}

async function main() {
  console.log("Verifying bundle products...\n");

  // Fetch all products tagged as bundles
  const { products } = await shopifyRequest(
    "/products.json?product_type=Bundle&limit=50"
  );

  if (products.length === 0) {
    console.log("No bundle products found. Run create-bundles.js first.");
    return;
  }

  console.log(`Found ${products.length} bundle product(s):\n`);

  for (const p of products) {
    const variant = p.variants[0];
    const savings = variant.compare_at_price
      ? (parseFloat(variant.compare_at_price) - parseFloat(variant.price)).toFixed(2)
      : "N/A";

    console.log(`  ${p.title}`);
    console.log(`    ID:       ${p.id}`);
    console.log(`    Handle:   ${p.handle}`);
    console.log(`    SKU:      ${variant.sku}`);
    console.log(`    Price:    $${variant.price}`);
    console.log(`    Was:      $${variant.compare_at_price || "N/A"}`);
    console.log(`    Savings:  $${savings}`);
    console.log(`    Status:   ${p.status}`);
    console.log(`    Tags:     ${p.tags}`);

    // Check metafields
    try {
      const { metafields } = await shopifyRequest(
        `/products/${p.id}/metafields.json`
      );
      const componentsMeta = metafields.find(
        (m) => m.namespace === "bundle" && m.key === "components"
      );
      if (componentsMeta) {
        const components = JSON.parse(componentsMeta.value);
        console.log(`    Components: ${components.map((c) => c.sku).join(", ")}`);
      }
    } catch {
      console.log(`    Components: (could not fetch metafields)`);
    }

    console.log("");
  }
}

main().catch(console.error);
