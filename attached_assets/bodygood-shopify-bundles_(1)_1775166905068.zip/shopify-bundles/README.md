# Body Good Studio - Shopify Upsell Bundles

Creates 5 pre-checkout upsell supplement bundles as products in Shopify.

## Bundles

| # | Bundle | Price | Was | Savings | Program |
|---|--------|-------|-----|---------|---------|
| 1 | GLP-1 Essentials | $99 | $125.69 | 21% | Weight Loss |
| 2 | Women's Wellness | $109 | $131.50 | 17% | Women's Wellness |
| 3 | Hair Revival | $119 | $148.90 | 20% | Hair |
| 4 | Performance + Recovery | $139 | $173.79 | 20% | Performance |
| 5 | GLP-1 Hair Rescue | $109 | $137.80 | 21% | Weight Loss + Hair |

## Bundle Contents

**GLP-1 Essentials ($99)**
- Complete Multivitamin (VOX4COMP)
- Probiotic 40 Billion (VOX4PROB)
- Magnesium Glycinate (VOX4MGNE)
- Hydration Powder - Peach Mango (OSM0HYMA)

**Women's Wellness ($109)**
- Ashwagandha (VOX4ASHW)
- Magnesium Glycinate (VOX4MGNE)
- Probiotic 40 Billion (VOX4PROB)
- Vitamin D3 2,000 IU (RLC3VTD3)
- Gut Detox / Acai Detox (VOX4MAXD)

**Hair Revival ($119)**
- Peptide Hair Growth Serum (FMN6PEHA)
- Botanical Hair Growth Serum (FMN6ROHA)
- Hair Oil for Scalp Health (FMN0HAGR)

**Performance + Recovery ($139)**
- Creatine Monohydrate (RLC4CREA)
- Plant Protein - Chocolate (JTP7PPCH)
- Hydration Powder - Peach Mango (OSM0HYMA)
- NAD+ Oral (JTP4NADP)

**GLP-1 Hair Rescue ($109)**
- Peptide Hair Growth Serum (FMN6PEHA)
- Berberine (JTP4BERB)
- Complete Multivitamin (VOX4COMP)

## Setup

```bash
npm install
cp .env.example .env
# Edit .env with your Shopify access token
```

## Getting a Shopify Access Token

1. Go to Shopify Admin > Settings > Apps and sales channels
2. Click "Develop apps" > "Create an app"
3. Name it "Bundle Creator"
4. Under API scopes, enable: `write_products`, `read_products`
5. Install the app and copy the Admin API access token

## Usage

```bash
# Create all 5 bundles (as DRAFT so you can review)
npm run create

# Verify bundles were created correctly
npm run verify

# Delete all bundles (if you need to start over)
npm run delete
```

## What Gets Created

Each bundle is created as a Shopify product with:
- **Product type:** "Bundle" (filterable in admin)
- **Status:** Draft (review before publishing)
- **Compare-at price:** Shows original retail total with strikethrough
- **Tags:** Program association + component SKUs for filtering
- **Metafields:**
  - `bundle.components` — JSON array of component handles/SKUs/quantities
  - `bundle.programs` — JSON array of associated programs
  - `bundle.savings_display` — Pre-calculated savings text

## Pre-Checkout Upsell Integration

The metafields are structured so your checkout/upsell logic can:

1. **Match bundles to programs** — Read `bundle.programs` to show the right
   bundle based on what the patient is buying (e.g., tirzepatide -> GLP-1 Essentials)
2. **Display savings** — Read `bundle.savings_display` for pre-formatted text
3. **Fulfill correctly** — Read `bundle.components` to know which individual
   products to pick/pack/ship when a bundle is ordered

### Example: Upsell Logic Pseudocode

```javascript
// When a patient adds a GLP-1 product to cart:
const cartProgram = "weight-loss";
const bundles = await getProductsByType("Bundle");
const matchingBundles = bundles.filter(b => {
  const programs = b.metafields.find(m => m.key === "programs");
  return JSON.parse(programs.value).includes(cartProgram);
});
// Show matchingBundles in pre-checkout upsell modal
```

## After Running

1. Go to Shopify Admin > Products
2. Filter by type "Bundle" 
3. Review descriptions, pricing, images
4. Add product images (not included in script)
5. Change status from Draft to Active when ready
6. Wire up the pre-checkout upsell UI in the custom platform
