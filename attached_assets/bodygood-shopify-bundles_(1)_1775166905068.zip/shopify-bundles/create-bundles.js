/**
 * Body Good Studio - Upsell Bundle Creator
 * Creates 5 supplement bundles as products in Shopify
 * 
 * USAGE:
 *   1. Set your Shopify credentials in .env
 *   2. npm install
 *   3. node create-bundles.js
 * 
 * This script creates each bundle as a Shopify product with:
 *   - Bundle title, description, pricing
 *   - "Bundle" product type for easy filtering
 *   - Tags linking to program + individual SKUs
 *   - Compare-at price showing full retail value
 *   - Metafields storing component product handles for checkout logic
 */

require("dotenv").config();

const SHOP_DOMAIN = process.env.SHOPIFY_SHOP_DOMAIN; // e.g. 573c26.myshopify.com
const ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;
const API_VERSION = "2024-10"; // update if needed

if (!SHOP_DOMAIN || !ACCESS_TOKEN) {
  console.error(
    "ERROR: Missing SHOPIFY_SHOP_DOMAIN or SHOPIFY_ACCESS_TOKEN in .env"
  );
  process.exit(1);
}

const BASE_URL = `https://${SHOP_DOMAIN}/admin/api/${API_VERSION}`;

// ---------------------------------------------------------------------------
// BUNDLE DEFINITIONS
// ---------------------------------------------------------------------------

const BUNDLES = [
  {
    title: "GLP-1 Essentials Bundle",
    handle: "glp1-essentials-bundle",
    productType: "Bundle",
    tags: [
      "bundle",
      "glp-1",
      "weight-loss",
      "upsell",
      "program:weight-loss",
      "sku:VOX4COMP",
      "sku:VOX4PROB",
      "sku:VOX4MGNE",
      "sku:OSM0HYMA",
    ],
    bundlePrice: "99.00",
    compareAtPrice: "125.69",
    sku: "BDL-GLP1-ESS",
    description: `<p><strong>Everything you need to thrive on your GLP-1 journey.</strong></p>
<p>Specifically curated for patients on tirzepatide or semaglutide to address the most common side effects and nutritional gaps.</p>
<ul>
  <li><strong>Complete Multivitamin</strong> — Replenish nutrients that GLP-1 medications can deplete</li>
  <li><strong>Probiotic 40 Billion with Prebiotics</strong> — Support your gut through GI side effects</li>
  <li><strong>Magnesium Glycinate</strong> — Ease constipation and muscle cramps</li>
  <li><strong>Hydration Powder (Peach Mango)</strong> — Combat dehydration and nausea</li>
</ul>
<p><em>Save over $25 compared to buying individually.</em></p>`,
    components: [
      { handle: "complete-multivitamin", sku: "VOX4COMP", qty: 1 },
      {
        handle: "probiotic-40-billion-with-prebiotics",
        sku: "VOX4PROB",
        qty: 1,
      },
      { handle: "magnesium-glycinate", sku: "VOX4MGNE", qty: 1 },
      { handle: "hydration-powder-peach-mango", sku: "OSM0HYMA", qty: 1 },
    ],
  },
  {
    title: "Women's Wellness Bundle",
    handle: "womens-wellness-bundle",
    productType: "Bundle",
    tags: [
      "bundle",
      "womens-wellness",
      "upsell",
      "program:womens-wellness",
      "sku:VOX4ASHW",
      "sku:VOX4MGNE",
      "sku:VOX4PROB",
      "sku:RLC3VTD3",
      "sku:VOX4MAXD",
    ],
    bundlePrice: "109.00",
    compareAtPrice: "131.50",
    sku: "BDL-WMNS-WELL",
    description: `<p><strong>Your daily wellness foundation, optimized for women 35+.</strong></p>
<p>Targets stress, gut health, hormonal balance, and the nutritional gaps that matter most.</p>
<ul>
  <li><strong>Ashwagandha</strong> — Manage stress and cortisol naturally</li>
  <li><strong>Magnesium Glycinate</strong> — Support sleep, mood, and hormone balance</li>
  <li><strong>Probiotic 40 Billion with Prebiotics</strong> — Gut health is hormone health</li>
  <li><strong>Vitamin D3 2,000 IU</strong> — Address the deficiency most women have</li>
  <li><strong>Gut Detox (Acai Detox)</strong> — Reduce bloating and support natural detox</li>
</ul>
<p><em>Save over $22 compared to buying individually.</em></p>`,
    components: [
      { handle: "ashwagandha", sku: "VOX4ASHW", qty: 1 },
      { handle: "magnesium-glycinate", sku: "VOX4MGNE", qty: 1 },
      {
        handle: "probiotic-40-billion-with-prebiotics",
        sku: "VOX4PROB",
        qty: 1,
      },
      { handle: "vitamin-d3-2-000-iu", sku: "RLC3VTD3", qty: 1 },
      { handle: "gut-detox-acai-detox", sku: "VOX4MAXD", qty: 1 },
    ],
  },
  {
    title: "Hair Revival Bundle",
    handle: "hair-revival-bundle",
    productType: "Bundle",
    tags: [
      "bundle",
      "hair",
      "upsell",
      "program:hair",
      "sku:FMN6PEHA",
      "sku:FMN6ROHA",
      "sku:FMN0HAGR",
    ],
    bundlePrice: "119.00",
    compareAtPrice: "148.90",
    sku: "BDL-HAIR-REV",
    description: `<p><strong>The complete hair growth system.</strong></p>
<p>A 3-product regimen combining peptide science, botanical actives, and scalp nourishment for visible results.</p>
<ul>
  <li><strong>Peptide Hair Growth Serum</strong> — Targeted peptide treatment for thinning hair</li>
  <li><strong>Botanical Hair Growth Serum</strong> — Complementary plant-based growth support</li>
  <li><strong>Hair Oil for Scalp Health and Hair Growth</strong> — Nourish and prep your scalp</li>
</ul>
<p><em>Save nearly $30 compared to buying individually.</em></p>`,
    components: [
      { handle: "peptide-hair-growth-serum", sku: "FMN6PEHA", qty: 1 },
      { handle: "botanical-hair-growth-serum", sku: "FMN6ROHA", qty: 1 },
      {
        handle: "hair-oil-for-scalp-health-and-hair-growth",
        sku: "FMN0HAGR",
        qty: 1,
      },
    ],
  },
  {
    title: "Performance + Recovery Bundle",
    handle: "performance-recovery-bundle",
    productType: "Bundle",
    tags: [
      "bundle",
      "performance",
      "recovery",
      "upsell",
      "program:performance",
      "sku:RLC4CREA",
      "sku:JTP7PPCH",
      "sku:OSM0HYMA",
      "sku:JTP4NADP",
    ],
    bundlePrice: "139.00",
    compareAtPrice: "173.79",
    sku: "BDL-PERF-REC",
    description: `<p><strong>Fuel your active lifestyle and protect lean muscle.</strong></p>
<p>Designed for patients who want to stay strong and energized, whether on GLP-1s or not.</p>
<ul>
  <li><strong>Creatine Monohydrate</strong> — Preserve and build lean muscle mass</li>
  <li><strong>Plant Protein (Chocolate)</strong> — Hit your daily protein goals deliciously</li>
  <li><strong>Hydration Powder (Peach Mango)</strong> — Replenish electrolytes post-workout</li>
  <li><strong>NAD+ (Oral)</strong> — Cellular energy and longevity support</li>
</ul>
<p><em>Save over $34 compared to buying individually.</em></p>`,
    components: [
      { handle: "creatine-monohydrate", sku: "RLC4CREA", qty: 1 },
      { handle: "plant-protein-chocolate", sku: "JTP7PPCH", qty: 1 },
      { handle: "hydration-powder-peach-mango", sku: "OSM0HYMA", qty: 1 },
      { handle: "nad", sku: "JTP4NADP", qty: 1 },
    ],
  },
  {
    title: "GLP-1 Hair Rescue Bundle",
    handle: "glp1-hair-rescue-bundle",
    productType: "Bundle",
    tags: [
      "bundle",
      "glp-1",
      "hair",
      "upsell",
      "program:weight-loss",
      "program:hair",
      "sku:FMN6PEHA",
      "sku:JTP4BERB",
      "sku:VOX4COMP",
    ],
    bundlePrice: "109.00",
    compareAtPrice: "137.80",
    sku: "BDL-GLP1-HAIR",
    description: `<p><strong>Fight GLP-1 hair thinning head-on.</strong></p>
<p>The targeted cross-sell for weight loss patients experiencing the most common fear: hair loss on Ozempic, Mounjaro, or Zepbound.</p>
<ul>
  <li><strong>Peptide Hair Growth Serum</strong> — Topical peptide treatment for thinning areas</li>
  <li><strong>Berberine</strong> — Metabolic and blood sugar support that complements your GLP-1</li>
  <li><strong>Complete Multivitamin</strong> — Nutritional foundation to fuel healthy hair growth</li>
</ul>
<p><em>Save nearly $29 compared to buying individually.</em></p>`,
    components: [
      { handle: "peptide-hair-growth-serum", sku: "FMN6PEHA", qty: 1 },
      { handle: "berberine", sku: "JTP4BERB", qty: 1 },
      { handle: "complete-multivitamin", sku: "VOX4COMP", qty: 1 },
    ],
  },
];

// ---------------------------------------------------------------------------
// SHOPIFY API HELPERS
// ---------------------------------------------------------------------------

async function shopifyRequest(endpoint, method = "GET", body = null) {
  const url = `${BASE_URL}${endpoint}`;
  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Access-Token": ACCESS_TOKEN,
    },
  };
  if (body) options.body = JSON.stringify(body);

  const response = await fetch(url, options);

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `Shopify API ${method} ${endpoint} failed (${response.status}): ${errorText}`
    );
  }

  // Handle rate limiting
  const remaining = response.headers.get("X-Shopify-Shop-Api-Call-Limit");
  if (remaining) {
    const [used, limit] = remaining.split("/").map(Number);
    if (used >= limit - 2) {
      console.log("  -> Approaching rate limit, pausing 1s...");
      await new Promise((r) => setTimeout(r, 1000));
    }
  }

  return response.json();
}

// ---------------------------------------------------------------------------
// CREATE A SINGLE BUNDLE PRODUCT
// ---------------------------------------------------------------------------

async function createBundleProduct(bundle) {
  console.log(`\nCreating: ${bundle.title}`);
  console.log(`  SKU: ${bundle.sku}`);
  console.log(`  Price: $${bundle.bundlePrice} (was $${bundle.compareAtPrice})`);

  // Step 1: Create the product
  const productPayload = {
    product: {
      title: bundle.title,
      handle: bundle.handle,
      body_html: bundle.description,
      vendor: "Body Good Studio",
      product_type: bundle.productType,
      tags: bundle.tags.join(", "),
      status: "draft", // create as draft so you can review before publishing
      variants: [
        {
          title: "Default Title",
          price: bundle.bundlePrice,
          compare_at_price: bundle.compareAtPrice,
          sku: bundle.sku,
          inventory_management: null, // no inventory tracking for bundles
          requires_shipping: true,
          taxable: true,
          weight: 0,
          weight_unit: "lb",
        },
      ],
    },
  };

  const { product } = await shopifyRequest("/products.json", "POST", productPayload);
  console.log(`  -> Product created: ID ${product.id}`);

  // Step 2: Add metafields with component data for checkout/fulfillment logic
  const metafieldPayload = {
    metafield: {
      namespace: "bundle",
      key: "components",
      value: JSON.stringify(bundle.components),
      type: "json",
    },
  };

  await shopifyRequest(
    `/products/${product.id}/metafields.json`,
    "POST",
    { metafield: metafieldPayload.metafield }
  );
  console.log(`  -> Metafield added: ${bundle.components.length} components`);

  // Step 3: Add program association metafield
  const programs = bundle.tags
    .filter((t) => t.startsWith("program:"))
    .map((t) => t.replace("program:", ""));

  const programMetafield = {
    metafield: {
      namespace: "bundle",
      key: "programs",
      value: JSON.stringify(programs),
      type: "json",
    },
  };

  await shopifyRequest(
    `/products/${product.id}/metafields.json`,
    "POST",
    { metafield: programMetafield.metafield }
  );
  console.log(`  -> Program metafield: ${programs.join(", ")}`);

  // Step 4: Add savings metafield
  const savings = (
    parseFloat(bundle.compareAtPrice) - parseFloat(bundle.bundlePrice)
  ).toFixed(2);
  const savingsPercent = (
    (parseFloat(savings) / parseFloat(bundle.compareAtPrice)) *
    100
  ).toFixed(0);

  const savingsMetafield = {
    metafield: {
      namespace: "bundle",
      key: "savings_display",
      value: JSON.stringify({
        amount: savings,
        percent: savingsPercent,
        message: `Save $${savings} (${savingsPercent}% off)`,
      }),
      type: "json",
    },
  };

  await shopifyRequest(
    `/products/${product.id}/metafields.json`,
    "POST",
    { metafield: savingsMetafield.metafield }
  );
  console.log(`  -> Savings: $${savings} (${savingsPercent}% off)`);

  return product;
}

// ---------------------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------------------

async function main() {
  console.log("==============================================");
  console.log("  Body Good Studio - Bundle Product Creator");
  console.log("==============================================");
  console.log(`Store: ${SHOP_DOMAIN}`);
  console.log(`Creating ${BUNDLES.length} bundle products...\n`);

  const results = [];

  for (const bundle of BUNDLES) {
    try {
      const product = await createBundleProduct(bundle);
      results.push({ title: bundle.title, id: product.id, status: "created" });
    } catch (err) {
      console.error(`  ERROR: ${err.message}`);
      results.push({ title: bundle.title, id: null, status: `error: ${err.message}` });
    }

    // Small delay between products to stay within rate limits
    await new Promise((r) => setTimeout(r, 500));
  }

  // Summary
  console.log("\n==============================================");
  console.log("  RESULTS SUMMARY");
  console.log("==============================================");
  results.forEach((r) => {
    const icon = r.status === "created" ? "[OK]" : "[!!]";
    console.log(`  ${icon} ${r.title} -> ${r.id || r.status}`);
  });

  const success = results.filter((r) => r.status === "created").length;
  console.log(`\n${success}/${BUNDLES.length} bundles created as DRAFT.`);
  console.log("Go to Shopify Admin > Products to review and publish.\n");
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
